# Question 2: Defining an array (list)
my_array = [1, 4, 7, 9]